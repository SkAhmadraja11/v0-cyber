// Background Service Worker for Phishing Detective Enterprise
// Continuously monitors navigation and scans in the background

const API_ENDPOINT = 'http://localhost:3000/api/real-scan';

// Cache for scan results to avoid spamming the API
const scanCache = new Map();

// Listen for tab updates
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url && tab.url.startsWith('http')) {
        scanUrl(tabId, tab.url);
    }
});

// Initialize Side Panel Behavior
// This ensures clicking the icon opens the side panel instead of doing nothing
chrome.runtime.onInstalled.addListener(() => {
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
});

async function scanUrl(tabId, url) {
    // Basic debounce / cache check
    if (scanCache.has(url)) {
        updateBadge(tabId, scanCache.get(url));
        return;
    }

    try {
        // Set loading state
        chrome.action.setBadgeText({ text: '...', tabId });
        chrome.action.setBadgeBackgroundColor({ color: '#666', tabId });

        console.log('Scanning:', url);

        const response = await fetch(API_ENDPOINT, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ input: url, mode: 'url' })
        });

        const data = await response.json();
        const result = data; // API returns result directly now

        if (result && result.verdict) {
            scanCache.set(url, result);
            updateBadge(tabId, result);
            handleThreat(tabId, result);
        }
    } catch (error) {
        console.error('Background Scan Error:', error);
        chrome.action.setBadgeText({ text: 'ERR', tabId });
    }
}

function updateBadge(tabId, result) {
    let text = 'SAFE';
    let color = '#00ff9d';

    if (result.verdict === 'MALICIOUS') {
        text = 'MALWARE';
        color = '#ff0055';
    } else if (result.verdict === 'HIGH_RISK') {
        text = 'RISK';
        color = '#ff0055';
    } else if (result.verdict === 'SUSPICIOUS') {
        text = 'WARN';
        color = '#ffb700';
    } else {
        text = 'OK';
    }

    chrome.action.setBadgeText({ text, tabId });
    chrome.action.setBadgeBackgroundColor({ color, tabId });
}

function handleThreat(tabId, result) {
    if (result.verdict === 'MALICIOUS' || result.verdict === 'HIGH_RISK') {
        // 1. Notify the user
        chrome.notifications.create({
            type: 'basic',
            iconUrl: 'icon.png',
            title: 'CRITICAL THREAT DETECTED',
            message: `This page is ${result.verdict}. ${result.threat_type?.[0] || 'Phishing'} detected.`,
            priority: 2
        });

        // 2. Inject content script to block view
        chrome.scripting.executeScript({
            target: { tabId },
            func: (data) => {
                // This function runs in the context of the webpage
                try {
                    const blockOverlay = document.createElement('div');
                    Object.assign(blockOverlay.style, {
                        position: 'fixed',
                        top: '0',
                        left: '0',
                        width: '100%',
                        height: '100%',
                        backgroundColor: '#0d0d12',
                        color: '#ff0055',
                        zIndex: '99999999',
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontFamily: 'sans-serif',
                        textAlign: 'center'
                    });

                    blockOverlay.innerHTML = `
                        <div style="background: rgba(255,0,85,0.1); padding: 40px; border: 2px solid #ff0055; border-radius: 16px; max-width: 600px;">
                            <h1 style="font-size: 3rem; margin: 0 0 20px 0;">🚫 BLOCKED</h1>
                            <h2 style="color: white; margin-bottom: 20px;">Phishing Detective blocked this unsafe site</h2>
                            <p style="color: #ccc; font-size: 1.2rem; margin-bottom: 30px;">
                                <strong>Verdict:</strong> ${data.verdict}<br>
                                <strong>Reason:</strong> ${data.key_indicators?.[0] || 'Malicious Activity'}
                            </p>
                            <button id="unsafe-proceed" style="background: transparent; border: 1px solid #666; color: #666; padding: 10px 20px; cursor: pointer;">
                                I understand the risks, proceed anyway
                            </button>
                        </div>
                    `;

                    document.body.appendChild(blockOverlay);
                    document.body.style.overflow = 'hidden'; // Stop scrolling

                    document.getElementById('unsafe-proceed').addEventListener('click', () => {
                        blockOverlay.remove();
                        document.body.style.overflow = 'auto';
                    });
                } catch (e) { console.error(e); }
            },
            args: [result]
        });
    }
}
