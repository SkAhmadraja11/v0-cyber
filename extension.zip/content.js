// PhiusGuard Content Script (Desktop Extension)
// Injects inline warnings directly into Gmail UI

console.log('🛡️ PhiusGuard Active: Monitoring Gmail Interface');

// Listen for messages from background
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'check_content') {
        // Basic page scan
        const bodyText = document.body.innerText;
        sendResponse({ text: bodyText.substring(0, 5000) });
    }
    else if (request.action === 'show_warning') {
        // Received a specific threat warning from Background
        injectGmailWarning(request.data);
    }
});

// Gmail-Specific DOM Injection
function injectGmailWarning(data) {
    // Target the email subject area or reading pane
    // Gmail classes are obfuscated, so we look for standard containers or high-level IDs
    const emailContainer = document.querySelector('.nH.hx') || document.querySelector('[role="main"]');

    if (emailContainer) {
        // Check if warning already exists
        if (document.getElementById('phius-warning-banner')) return;

        const banner = document.createElement('div');
        banner.id = 'phius-warning-banner';
        Object.assign(banner.style, {
            backgroundColor: '#fee2e2', // Light red
            border: '1px solid #ef4444', // Red border
            color: '#991b1b', // Dark red text
            padding: '16px',
            margin: '10px 20px',
            borderRadius: '8px',
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
            boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
            zIndex: '9999'
        });

        banner.innerHTML = `
            <div style="font-size: 24px;">⚠️</div>
            <div style="flex: 1;">
                <div style="font-weight: 700; font-size: 14px;">PhiusGuard Security Warning</div>
                <div style="font-size: 13px;">This email contains <b>${data.threat_type || 'suspicious elements'}</b>. Verdict: ${data.verdict}</div>
                <div style="font-size: 11px; margin-top: 4px; color: #b91c1c;">${data.key_indicators?.[0] || 'Be cautious with links and attachments.'}</div>
            </div>
            <button id="phius-dismiss" style="background: transparent; border: 1px solid #b91c1c; border-radius: 4px; padding: 4px 12px; color: #b91c1c; cursor: pointer; font-size: 12px; font-weight: 600;">Dismiss</button>
        `;

        // Insert at the top of the container
        emailContainer.insertBefore(banner, emailContainer.firstChild);

        document.getElementById('phius-dismiss').addEventListener('click', () => {
            banner.remove();
        });
    }
}

