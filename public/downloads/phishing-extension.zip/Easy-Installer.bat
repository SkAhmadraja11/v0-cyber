@echo off
TITLE Phishing Detective Enterprise - Installer Helper
COLOR 0A

CLS
ECHO ========================================================
ECHO    PHISHING DETECTIVE ENTERPRISE - INSTALLATION HELPER
ECHO ========================================================
ECHO.
ECHO This script will help you load the extension into Chrome.
ECHO.
ECHO STEPS:
ECHO 1. We will open the "Extensions" page in Chrome.
ECHO 2. Enable "Developer mode" (Top Right Toggle) if not enabled.
ECHO 3. Drag and drop the "extension" folder from the file window into Chrome.
ECHO    (Or click "Load Unpacked" and select this folder).
ECHO.
ECHO Press any key to start...
PAUSE > NUL

:: Open Chrome Extensions Page
start chrome://extensions
if %errorlevel% neq 0 (
    echo.
    echo Could not open Chrome automatically. Please open 'chrome://extensions' manually.
)

:: Open Current Folder
start .

ECHO.
ECHO ========================================================
ECHO    ACTION REQUIRED:
ECHO    1. Toggle 'Developer mode' ON in Chrome.
ECHO    2. Drag the 'extension' folder into the Chrome window.
ECHO ========================================================
ECHO.
ECHO Installation will be complete once the icon appears in your toolbar.
ECHO.
PAUSE
