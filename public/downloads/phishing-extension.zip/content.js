// Phishing Detective Content Script
// Runs on every page load to prepare for communication

console.log('🛡️ Phishing Detective Active on this page');

// Listen for messages from background
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'check_content') {
        const bodyText = document.body.innerText;
        sendResponse({ text: bodyText.substring(0, 5000) }); // Send first 5k chars for analysis
    }
});
